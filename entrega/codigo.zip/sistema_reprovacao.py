"""Sistema de Reprovacao: codigo-fonte completo em um unico arquivo.

Equipe: Eduardo Moscatelli Martinho, Lucas Youssif Abdallah Catore e
Ryan Henrique Escandelari Marcato.

Cada bloco abaixo corresponde a um modulo da pasta sistema/ do repositorio.
Para rodar: python sistema_reprovacao.py
A previsao procura as turmas passadas na pasta dados/historico, ao lado deste
arquivo, ou na pasta informada em --historico.
"""

import argparse
import csv
import json
import math
import sys
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from statistics import StatisticsError, linear_regression, mean
from typing import Optional


# ==================== leitores.py ====================

class DadosInvalidosError(ValueError):
    """Arquivo de entrada com formato ou conteudo invalido."""


class Leitor:
    """ler() define os passos da leitura. Cada formato muda apenas
    ler_conteudo() e validar()."""

    def ler(self, caminho):
        caminho = Path(caminho)
        self.verificar_existe(caminho)
        conteudo = self.ler_conteudo(caminho)
        self.validar(caminho, conteudo)
        return conteudo

    def verificar_existe(self, caminho):
        if not caminho.is_file():
            raise DadosInvalidosError(f"Arquivo não encontrado: {caminho}")

    def ler_conteudo(self, caminho):
        raise NotImplementedError

    def validar(self, caminho, conteudo):
        raise NotImplementedError


class LeitorCSV(Leitor):
    """Devolve (colunas, linhas). Cada linha e um par (numero da linha, dados)."""

    def __init__(self, colunas_obrigatorias=()):
        self.colunas_obrigatorias = colunas_obrigatorias

    def ler_conteudo(self, caminho):
        with caminho.open(newline="", encoding="utf-8-sig") as arquivo:
            leitor = csv.DictReader(arquivo)
            colunas = [coluna.strip() for coluna in (leitor.fieldnames or [])]
            linhas = []
            for numero, linha in enumerate(leitor, start=2):
                limpa = {
                    chave.strip(): (valor or "").strip()
                    for chave, valor in linha.items()
                    if chave
                }
                linhas.append((numero, limpa))
        return colunas, linhas

    def validar(self, caminho, conteudo):
        colunas, _ = conteudo
        faltando = [c for c in self.colunas_obrigatorias if c not in colunas]
        if faltando:
            raise DadosInvalidosError(
                f"{caminho.name}: coluna(s) obrigatória(s) ausente(s): "
                f"{', '.join(faltando)}"
            )


class LeitorJSON(Leitor):
    """Devolve o objeto (dicionario) do arquivo JSON."""

    def ler_conteudo(self, caminho):
        try:
            return json.loads(caminho.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as erro:
            raise DadosInvalidosError(f"{caminho.name}: JSON inválido ({erro}).") from None

    def validar(self, caminho, conteudo):
        if not isinstance(conteudo, dict) or not conteudo:
            raise DadosInvalidosError(f"{caminho.name}: esperado um objeto JSON com as regras.")


# ==================== calculo.py ====================

MEDIA_APROVACAO = 6.0
NOTA_MAXIMA = 10.0

SITUACAO_APROVADO = "aprovado"
SITUACAO_REPROVADO = "reprovado"
SITUACAO_EM_RISCO = "em risco"

RESULTADO_RECUPERACAO = "Recuperação"
RESULTADO_REPROVADO = "Reprovado"

#Regras de presenca: (nota minima, presenca minima em %), da maior nota para a menor
FAIXAS_PRESENCA = [(8.0, 50), (6.5, 65)]
PRESENCA_PADRAO = 75

#Tolerancia para comparar numeros de ponto flutuante
_EPS = 1e-9


def _atingiu(valor, minimo):
    return valor >= minimo - _EPS


#HISTORIA 1: nota atual
def calcular_nota_atual(notas, regras):
    """H1: soma de (nota x peso) das avaliações ja realizadas. Avaliacoes pendentes nao entram na soma."""
    total = 0.0
    for avaliacao, peso in regras["avaliacoes"].items():
        nota = notas.get(avaliacao)
        if nota is not None:
            total += nota * peso
    return total


def calcular_peso_pendente(notas, regras):
    """Soma dos pesos das avaliacoes que ainda nao foram realizadas."""
    return sum(
        peso
        for avaliacao, peso in regras["avaliacoes"].items()
        if notas.get(avaliacao) is None
    )


#HISTORIA 4: nota necessAria e recuperacao
def calcular_nota_recuperacao(media_final, media_aprovacao=MEDIA_APROVACAO):
    """Nota necessária na recuperação para chegar à média de aprovação, (média + recuperação) / 2"""
    return 2 * media_aprovacao - media_final


def calcular_nota_necessaria(notas, regras):
    """nota que o aluno precisa tirar nas avaliações pendentes."""
    media = regras.get("media_aprovacao", MEDIA_APROVACAO)
    atual = calcular_nota_atual(notas, regras)

    if _atingiu(atual, media):
        return 0.0

    pendente = calcular_peso_pendente(notas, regras)
    if pendente > _EPS:
        necessaria = (media - atual) / pendente
        if necessaria <= NOTA_MAXIMA + _EPS:
            return necessaria

    #Nao da para passar so nas avaliacoes regulares: a recuperacao e possivel
    melhor_media = atual + NOTA_MAXIMA * pendente
    if calcular_nota_recuperacao(melhor_media, media) <= NOTA_MAXIMA + _EPS:
        return RESULTADO_RECUPERACAO
    return RESULTADO_REPROVADO


#Presenca e faltas regras fixas + historia 3
def presenca_minima_percentual(nota):
    for nota_minima, percentual in FAIXAS_PRESENCA:
        if _atingiu(nota, nota_minima):
            return percentual
    return PRESENCA_PADRAO


def presenca_minima(nota):
    return presenca_minima_percentual(nota) / 100


def _validar_aulas_e_faltas(aulas_totais, faltas):
    if aulas_totais <= 0:
        raise ValueError("O total de aulas deve ser maior que zero.")
    if faltas < 0:
        raise ValueError("O número de faltas nao pode ser negativo.")
    if faltas > aulas_totais:
        raise ValueError("O numero de faltas nao pode ser maior que o total de aulas.")


def calcular_presenca(aulas_totais, faltas):
    """Fracao de presença do aluno (0 a 1) com base nas faltas ate agora."""
    _validar_aulas_e_faltas(aulas_totais, faltas)
    return (aulas_totais - faltas) / aulas_totais


def calcular_faltas_permitidas(aulas_totais, faltas, nota_atual):
    """H3: quantas faltas o aluno ainda pode ter sem perder por frequencia."""
    _validar_aulas_e_faltas(aulas_totais, faltas)
    percentual_maximo_de_faltas = 100 - presenca_minima_percentual(nota_atual)
    limite = int(aulas_totais) * percentual_maximo_de_faltas // 100
    return max(0, limite - int(faltas))


#HISTORIA 2: situacao
def _frequencia_suficiente(presenca, nota):
    return _atingiu(presenca, presenca_minima(nota))


def _classificar_com_presenca(atual, pendente, media, presenca):
    if not 0 <= presenca <= 1:
        raise ValueError("A presença deve ser uma fração entre 0 e 1.")

    if _atingiu(atual, media):
        if _frequencia_suficiente(presenca, atual):
            return SITUACAO_APROVADO
        if pendente <= _EPS:
            return SITUACAO_REPROVADO  #tudo realizado e frequencia insuficiente

    #Ainda ha chance de a nota subir e baixar a exigencia de presenca.
    if _frequencia_suficiente(presenca, atual + NOTA_MAXIMA * pendente):
        return SITUACAO_EM_RISCO
    return SITUACAO_REPROVADO


def classificar_situacao(notas, regras, presenca=None):
    """H2: "aprovado", "reprovado" ou "em risco"."""
    if calcular_nota_necessaria(notas, regras) == RESULTADO_REPROVADO:
        return SITUACAO_REPROVADO

    media = regras.get("media_aprovacao", MEDIA_APROVACAO)
    atual = calcular_nota_atual(notas, regras)
    if presenca is None:
        return SITUACAO_APROVADO if _atingiu(atual, media) else SITUACAO_EM_RISCO

    pendente = calcular_peso_pendente(notas, regras)
    return _classificar_com_presenca(atual, pendente, media, presenca)


# ==================== carregador.py ====================

NOTA_MINIMA, NOTA_MAXIMA = 0.0, 10.0


#AUXILIARES
def converter_nota(texto, onde):
    """'' -> None (pendente); aceita vírgula decimal; exige 0 <= nota <= 10."""
    if texto == "":
        return None
    try:
        nota = float(texto.replace(",", "."))
    except ValueError:
        raise DadosInvalidosError(f"{onde}: nota inválida '{texto}'.") from None
    if not NOTA_MINIMA <= nota <= NOTA_MAXIMA:
        raise DadosInvalidosError(f"{onde}: nota {nota:g} fora do intervalo 0 a 10.")
    return nota


def _converter_inteiro(texto, onde, campo):
    try:
        valor = int(texto)
    except ValueError:
        raise DadosInvalidosError(f"{onde}: {campo} inválido '{texto}'.") from None
    if valor < 0:
        raise DadosInvalidosError(f"{onde}: {campo} não pode ser negativo.")
    return valor


#REGRAS DO PROFESSOR
def _validar_regra(conteudo, onde):
    """Valida as regras de UMA materia e devolve {media_aprovacao, avaliacoes}."""
    if not isinstance(conteudo, dict) or "avaliacoes" not in conteudo:
        raise DadosInvalidosError(f"{onde}: campo 'avaliacoes' é obrigatório.")

    media = conteudo.get("media_aprovacao", 6.0)
    if isinstance(media, bool) or not isinstance(media, (int, float)):
        raise DadosInvalidosError(f"{onde}: 'media_aprovacao' deve ser numérica.")
    if not 0 < media <= NOTA_MAXIMA:
        raise DadosInvalidosError(f"{onde}: 'media_aprovacao' deve estar entre 0 e 10.")

    avaliacoes = conteudo["avaliacoes"]
    if not isinstance(avaliacoes, dict) or not avaliacoes:
        raise DadosInvalidosError(f"{onde}: 'avaliacoes' deve ter ao menos uma avaliação.")
    pesos = {}
    for nome, peso in avaliacoes.items():
        if isinstance(peso, bool) or not isinstance(peso, (int, float)) or peso <= 0:
            raise DadosInvalidosError(f"{onde}: peso de '{nome}' deve ser um número > 0.")
        pesos[nome] = float(peso)
    if abs(sum(pesos.values()) - 1.0) > 1e-6:
        raise DadosInvalidosError(f"{onde}: os pesos devem somar 1 (somam {sum(pesos.values()):g}).")
    return {"media_aprovacao": float(media), "avaliacoes": pesos}


def carregar_regras(caminho):
    """Le o JSON com várias materias: {disciplina: {media_aprovacao, avaliacoes}}."""
    nome = Path(caminho).name
    bruto = LeitorJSON().ler(caminho)
    return {
        disciplina: _validar_regra(conteudo, f"{nome}, disciplina '{disciplina}'")
        for disciplina, conteudo in bruto.items()
    }


def carregar_regras_da_materia(caminho, materia):
    """Le o JSON de UMA matéria. Aceita dois formatos:"""
    nome = Path(caminho).name
    bruto = LeitorJSON().ler(caminho)
    if "avaliacoes" in bruto:
        return _validar_regra(bruto, nome)

    regras = carregar_regras(caminho)
    por_nome = {normalizar_nome(disciplina): regra for disciplina, regra in regras.items()}
    if normalizar_nome(materia) not in por_nome:
        raise DadosInvalidosError(
            f"{nome}: não há regras para a matéria '{materia}' (o arquivo tem: {', '.join(regras)})."
        )
    return por_nome[normalizar_nome(materia)]


# Notas e faltas do aluno (CSV)
def carregar_notas(caminho):
    """Le o CSV do aluno. Devolve {disciplina: {avaliacao: nota | None}}."""
    nome = Path(caminho).name
    _, linhas = LeitorCSV(["disciplina", "avaliacao", "nota"]).ler(caminho)
    notas = {}
    for numero, linha in linhas:
        onde = f"{nome}, linha {numero}"
        disciplina, avaliacao = linha["disciplina"], linha["avaliacao"]
        if not disciplina or not avaliacao:
            raise DadosInvalidosError(f"{onde}: 'disciplina' e 'avaliacao' são obrigatórias.")
        por_disciplina = notas.setdefault(disciplina, {})
        if avaliacao in por_disciplina:
            raise DadosInvalidosError(f"{onde}: avaliação '{avaliacao}' repetida em '{disciplina}'.")
        por_disciplina[avaliacao] = converter_nota(linha["nota"], onde)
    if not notas:
        raise DadosInvalidosError(f"{nome}: o arquivo não tem nenhuma nota.")
    return notas


def carregar_frequencia(caminho):
    """Le as colunas opcionais aulas_totais e faltas do CSV do aluno."""
    nome = Path(caminho).name
    colunas, linhas = LeitorCSV(["disciplina"]).ler(caminho)
    frequencia = {}
    if "aulas_totais" not in colunas or "faltas" not in colunas:
        return frequencia

    for numero, linha in linhas:
        onde = f"{nome}, linha {numero}"
        if linha["aulas_totais"] == "" and linha["faltas"] == "":
            continue
        if linha["aulas_totais"] == "" or linha["faltas"] == "":
            raise DadosInvalidosError(f"{onde}: informe 'aulas_totais' e 'faltas' juntos.")
        atual = {
            "aulas_totais": _converter_inteiro(linha["aulas_totais"], onde, "aulas_totais"),
            "faltas": _converter_inteiro(linha["faltas"], onde, "faltas"),
        }
        if atual["aulas_totais"] == 0:
            raise DadosInvalidosError(f"{onde}: 'aulas_totais' deve ser maior que zero.")
        if atual["faltas"] > atual["aulas_totais"]:
            raise DadosInvalidosError(f"{onde}: 'faltas' maior que 'aulas_totais'.")
        anterior = frequencia.setdefault(linha["disciplina"], atual)
        if anterior != atual:
            raise DadosInvalidosError(
                f"{onde}: valores de faltas/aulas diferentes para '{linha['disciplina']}'."
            )
    return frequencia


def validar_consistencia(notas, regras):
    """Confere se as disciplinas e avaliações do CSV existem no JSON de regras."""
    for disciplina, avaliacoes in notas.items():
        if disciplina not in regras:
            raise DadosInvalidosError(f"Disciplina '{disciplina}' não tem regras no JSON.")
        desconhecidas = set(avaliacoes) - set(regras[disciplina]["avaliacoes"])
        if desconhecidas:
            raise DadosInvalidosError(
                f"Disciplina '{disciplina}': avaliação(ões) fora das regras: "
                f"{', '.join(sorted(desconhecidas))}."
            )


#Uma materia por vez: CSV de notas + JSON de regras
@dataclass
class Materia:
    nome: str                       
    notas: dict                     
    regras: dict                    
    frequencia: Optional[dict]      


def carregar_materia(caminho_notas, caminho_regras):
    """Le e valida o CSV do aluno (UMA materia) e o JSON com as regras dela."""
    notas = carregar_notas(caminho_notas)
    if len(notas) != 1:
        raise DadosInvalidosError(
            f"{Path(caminho_notas).name}: o arquivo tem {len(notas)} matérias ({', '.join(notas)}). "
            "Envie um arquivo por matéria."
        )
    (nome, notas_da_materia), = notas.items()
    regras = carregar_regras_da_materia(caminho_regras, nome)
    validar_consistencia({nome: notas_da_materia}, {nome: regras})
    return Materia(nome, notas_da_materia, regras, carregar_frequencia(caminho_notas).get(nome))


#Historico de turmas passadas: um CSV por materia
def normalizar_nome(nome):
    sem_acento = unicodedata.normalize("NFKD", nome).encode("ascii", "ignore").decode("ascii")
    return "".join(c for c in sem_acento.casefold() if c not in " _-")


def listar_materias_com_historico(pasta):
    pasta = Path(pasta)
    if not pasta.is_dir():
        return {}
    return {normalizar_nome(arquivo.stem): arquivo for arquivo in sorted(pasta.glob("*.csv"))}


def buscar_historico(pasta, materia):
    caminho = listar_materias_com_historico(pasta).get(normalizar_nome(materia))
    if caminho is None:
        return None

    nome = caminho.name
    colunas, linhas = LeitorCSV().ler(caminho)
    avaliacoes = [c for c in colunas if c and c.casefold() != "aluno"]
    if not avaliacoes:
        raise DadosInvalidosError(f"{nome}: nenhuma coluna de avaliação encontrada.")
    return [
        {a: converter_nota(linha.get(a, ""), f"{nome}, linha {numero}") for a in avaliacoes}
        for numero, linha in linhas
    ]


# ==================== predicao.py ====================

MIN_ALUNOS = 10  #minimo de alunos de turmas passadas para confiar na reta
_TOLERANCIA = 1e-9  #evita que 5,99999 conte como menor que 6


class PrevisaoIndisponivelError(ValueError):
    """Nao eh possível prever"""


@dataclass
class RegressaoSimples:
    """Reta y = intercepto + coeficiente x x e a qualidade do ajuste."""

    intercepto: float
    coeficiente: float
    erro_padrao: float 
    r2: float #0 a 1: quanto da variacao das notas a reta explica

    @classmethod
    def treinar(cls, xs, ys):
        if len(xs) < 3:
            raise PrevisaoIndisponivelError("Sao necessárias ao menos 3 observacoes para a regressao.")
        try:
            coeficiente, intercepto = linear_regression(xs, ys)
        except StatisticsError:  
            raise PrevisaoIndisponivelError(
                "Todos os alunos do historico tiraram a mesma nota base: nao da para ajustar a reta."
            ) from None

        soma_erros = sum((y - (intercepto + coeficiente * x)) ** 2 for x, y in zip(xs, ys))
        soma_total = sum((y - mean(ys)) ** 2 for y in ys)
        return cls(
            intercepto=intercepto,
            coeficiente=coeficiente,
            erro_padrao=math.sqrt(soma_erros / (len(xs) - 2)),
            r2=max(0.0, 1 - soma_erros / soma_total) if soma_total else 0.0,
        )

    def prever(self, x):
        return self.intercepto + self.coeficiente * x


@dataclass
class Predicao:
    base: object                #avaliacao usada como entrada 
    notas_previstas: dict       
    modelos: dict               
    media_final_prevista: float
    desvio_media_final: float
    chance_aprovacao: float     
    n_treino: int = 0          

    @property
    def chance_abaixo_da_media(self):
        """Chance de terminar abaixo da media."""
        return 1 - self.chance_aprovacao


def _alunos_para_treino(historico, avaliacoes):
    """So entram no treino os alunos que tem todas as notas necessarias."""
    alunos = [
        aluno for aluno in historico
        if all(aluno.get(a) is not None for a in avaliacoes)
    ]
    if len(alunos) < MIN_ALUNOS:
        raise PrevisaoIndisponivelError(
            f"o histórico tem só {len(alunos)} aluno(s) com as notas {', '.join(avaliacoes)} "
            f"(mínimo {MIN_ALUNOS})."
        )
    return alunos


def _treinar_modelos(alunos, base, pendentes):
    """Uma reta para cada avaliacao pendente, todas a partir da mesma nota base."""
    xs = [aluno[base] for aluno in alunos]
    return {a: RegressaoSimples.treinar(xs, [aluno[a] for aluno in alunos]) for a in pendentes}


def _limitar_nota(nota):
    return min(max(nota, 0.0), NOTA_MAXIMA)


def _calcular_chance(media_prevista, desvio, media):
    """P(media final >= media de aprovacao), supondo erros com distribuicao normal."""
    if desvio == 0:
        return float(media_prevista >= media - _TOLERANCIA)
    return 0.5 * math.erfc((media - media_prevista) / desvio / math.sqrt(2))


def prever(historico, notas, regras):
    """Preve as avaliacoes pendentes e a chance de aprovacao. historico: lista de {avaliacao: nota | None}, um dict por aluno de turmas
    passadas (saida de carregador.buscar_historico). notas / regras: formato de sistema.calculo, de uma disciplina.
    """
    pesos = regras["avaliacoes"]
    media = regras.get("media_aprovacao", MEDIA_APROVACAO)
    atual = calcular_nota_atual(notas, regras)
    conhecidas = [a for a in pesos if notas.get(a) is not None]
    pendentes = [a for a in pesos if a not in conhecidas]

    if not pendentes:
        return Predicao(None, {}, {}, atual, 0.0, _calcular_chance(atual, 0.0, media))
    if not conhecidas:
        raise PrevisaoIndisponivelError(
            "informe ao menos uma nota ja obtida: a regressão simples precisa de uma nota de partida."
        )

    base = conhecidas[-1]  # a ultima nota que o aluno tirou
    alunos = _alunos_para_treino(historico, [base] + pendentes)
    modelos = _treinar_modelos(alunos, base, pendentes)

    previstas = {a: _limitar_nota(modelos[a].prever(notas[base])) for a in pendentes}
    media_prevista = atual + sum(pesos[a] * previstas[a] for a in pendentes)
    desvio = sum(pesos[a] * modelos[a].erro_padrao for a in pendentes)
    chance = _calcular_chance(media_prevista, desvio, media)

    return Predicao(base, previstas, modelos, media_prevista, desvio, chance, len(alunos))


# ==================== relatorio.py ====================

@dataclass
class RelatorioDisciplina:
    disciplina: str
    nota_atual: float
    situacao: str
    nota_necessaria: object            
    avaliacoes_pendentes: list
    aulas_totais: Optional[int] = None
    faltas: Optional[int] = None
    presenca: Optional[float] = None
    presenca_minima: Optional[float] = None
    faltas_permitidas: Optional[int] = None


def gerar_relatorio(materia):
    """Situação da matéria (histórias 1 a 4). `materia` é um carregador.Materia."""
    atual = calcular_nota_atual(materia.notas, materia.regras)
    freq = materia.frequencia
    presenca = calcular_presenca(**freq) if freq else None

    relatorio = RelatorioDisciplina(
        disciplina=materia.nome,
        nota_atual=atual,
        situacao=classificar_situacao(materia.notas, materia.regras, presenca),
        nota_necessaria=calcular_nota_necessaria(materia.notas, materia.regras),
        avaliacoes_pendentes=[a for a in materia.regras["avaliacoes"] if materia.notas.get(a) is None],
    )
    if freq:
        relatorio.aulas_totais = freq["aulas_totais"]
        relatorio.faltas = freq["faltas"]
        relatorio.presenca = presenca
        relatorio.presenca_minima = presenca_minima(atual)
        relatorio.faltas_permitidas = calcular_faltas_permitidas(
            freq["aulas_totais"], freq["faltas"], atual
        )
    return relatorio


def gerar_previsao(materia, nome_do_arquivo, pasta_historico):
    """Preve as notas pendentes da materia, se houver historico com o mesmo nome do arquivo."""
    historico = buscar_historico(pasta_historico, nome_do_arquivo)
    if historico is None:
        disponiveis = ", ".join(a.stem for a in listar_materias_com_historico(pasta_historico).values())
        raise PrevisaoIndisponivelError(
            f"não há dados de turmas passadas para '{nome_do_arquivo}'. "
            f"Matérias disponíveis: {disponiveis or 'nenhuma'}. "
            "Para prever, o arquivo de notas deve ter o mesmo nome de uma delas."
        )
    return prever(historico, materia.notas, materia.regras)

def formatar_numero(valor, casas=2):
    return f"{valor:.{casas}f}".replace(".", ",")


def formatar_percentual(fracao):
    """Percentual pt-BR; previsões nunca são exibidas como 0% ou 100% exatos
    (só quando o resultado é certo, ou seja, exatamente 0 ou 1)."""
    if 0 < fracao < 0.001:
        return "< 0,1%"
    if 0.999 < fracao < 1:
        return "> 99,9%"
    return f"{formatar_numero(fracao * 100, 1)}%"


def _campo(rotulo, valor):
    """Linha 'Rótulo .......... valor' com a coluna de valores alinhada."""
    return f"{rotulo} ".ljust(26, ".") + f" {valor}"


def _descrever_nota_necessaria(rel):
    nec = rel.nota_necessaria
    if nec == RESULTADO_RECUPERACAO:
        return "acima de 10 nas pendentes -> só a recuperação pode salvar (Recuperação)"
    if nec == RESULTADO_REPROVADO:
        return "nem a recuperação é suficiente (Reprovado)"
    if nec == 0:
        return "0 (já alcançou a média de aprovação)"
    return f"{formatar_numero(nec)} em cada avaliação pendente ({', '.join(rel.avaliacoes_pendentes)})"


def formatar_predicao(predicao, recuo="  "):
    """Linhas de texto com a previsão (equação, notas previstas, média final e chances)."""
    linhas = []
    for avaliacao, nota in predicao.notas_previstas.items():
        m = predicao.modelos[avaliacao]
        linhas.append(
            f"{recuo}{avaliacao} prevista: {formatar_numero(nota)}  (erro típico ±{formatar_numero(m.erro_padrao)})"
        )
        linhas.append(
            f"{recuo}   reta: {avaliacao} = {formatar_numero(m.intercepto)} "
            f"{'+' if m.coeficiente >= 0 else '-'} {formatar_numero(abs(m.coeficiente))} x {predicao.base}"
            f"   [R² {formatar_numero(m.r2)}]"
        )
    if predicao.notas_previstas:
        linhas.append(
            f"{recuo}Média final prevista: {formatar_numero(predicao.media_final_prevista)}"
            f"  (±{formatar_numero(predicao.desvio_media_final)})"
        )
    linhas.append(f"{recuo}Chance de aprovação direta: {formatar_percentual(predicao.chance_aprovacao)}")
    linhas.append(
        f"{recuo}Chance de ficar abaixo da média (recuperação/reprovação): "
        f"{formatar_percentual(predicao.chance_abaixo_da_media)}"
    )
    return linhas


def formatar_relatorio(rel):
    """Texto do relatório de situação de uma matéria."""
    linhas = [
        f"=== {rel.disciplina} ===",
        _campo("Nota atual", formatar_numero(rel.nota_atual)),
        _campo("Situação", rel.situacao.upper()),
        _campo("Nota necessária", _descrever_nota_necessaria(rel)),
    ]
    if rel.faltas_permitidas is not None:
        linhas.append(_campo(
            "Frequência",
            f"{rel.faltas} falta(s) em {rel.aulas_totais} aulas "
            f"(presença {formatar_percentual(rel.presenca)}, "
            f"mínimo exigido {formatar_percentual(rel.presenca_minima)})",
        ))
        linhas.append(_campo("Faltas ainda permitidas", rel.faltas_permitidas))
    return "\n".join(linhas)


def formatar_previsao(materia, predicao):
    """Texto da previsão de uma matéria."""
    linhas = [
        f"=== Previsão: {materia.nome} ===",
        _campo("Nota atual", formatar_numero(calcular_nota_atual(materia.notas, materia.regras))),
    ]
    if not predicao.notas_previstas:
        linhas.append("Nada a prever: todas as avaliações já foram realizadas.")
    else:
        linhas.append(
            f"Previsão (regressão linear simples a partir da {predicao.base}; "
            f"{predicao.n_treino} alunos de turmas passadas):"
        )
        linhas.extend(formatar_predicao(predicao))
    return "\n".join(linhas)


# ==================== fachada.py ====================

class SistemaReprovacao:
    """Junta o carregador, o relatorio e a previsao em poucos metodos."""

    def __init__(self, pasta_historico):
        self.pasta_historico = pasta_historico

    def carregar_materia(self, caminho_notas, caminho_regras):
        return carregar_materia(caminho_notas, caminho_regras)

    def materias_com_previsao(self):
        arquivos = listar_materias_com_historico(self.pasta_historico).values()
        return sorted(arquivo.stem for arquivo in arquivos)

    def relatorio_situacao(self, materia):
        return formatar_relatorio(gerar_relatorio(materia))

    def relatorio_previsao(self, materia, caminho_notas):
        # o historico e achado pelo nome do arquivo de notas
        nome_do_arquivo = Path(caminho_notas).stem
        predicao = gerar_previsao(materia, nome_do_arquivo, self.pasta_historico)
        return formatar_previsao(materia, predicao)


# ==================== comandos.py ====================

class Terminal:
    """O que os comandos usam: o sistema, como ler e escrever e os ultimos arquivos."""

    def __init__(self, sistema, entrada, saida):
        self.sistema = sistema
        self.entrada = entrada
        self.saida = saida
        self.ultimos = {}  # para nao digitar os caminhos de novo

    def pedir_caminho(self, pergunta, ultimo):
        """Pede o caminho de um arquivo. Enter reaproveita o ultimo; '0' volta ao menu."""
        dica = f"Enter = usar o último ({Path(ultimo).name}), 0 = voltar" if ultimo else "0 = voltar"
        texto = self.entrada(f"{pergunta} [{dica}]: ").strip().strip("\"'")
        if texto == "0":
            return None
        return texto or ultimo

    def pedir_materia(self):
        """Devolve (Materia, caminho do CSV), ou None se o aluno voltou ou houve erro."""
        self.saida("\nUma matéria por vez. Modelos de arquivo: pasta exemplos/ (calculo1.csv e calculo1.json).")
        csv = self.pedir_caminho("Arquivo CSV com suas notas", self.ultimos.get("csv"))
        if not csv:
            return None
        regras = self.pedir_caminho("Arquivo JSON com as regras da matéria (pesos)", self.ultimos.get("json"))
        if not regras:
            return None
        try:
            materia = self.sistema.carregar_materia(csv, regras)
        except DadosInvalidosError as erro:
            self.saida(f"Erro: {erro}")
            return None
        self.ultimos["csv"], self.ultimos["json"] = csv, regras
        return materia, csv


class Comando:
    """Uma opcao do menu."""

    tecla = ""
    descricao = ""

    def executar(self, terminal):
        """Faz a opcao. Devolve False quando o menu deve fechar."""
        raise NotImplementedError


class ComandoSituacao(Comando):
    tecla = "1"
    descricao = "Ver minha situação em uma matéria"

    def executar(self, terminal):
        carregada = terminal.pedir_materia()
        if carregada:
            materia, _ = carregada
            terminal.saida("\n" + terminal.sistema.relatorio_situacao(materia))
        return True


class ComandoPrevisao(Comando):
    tecla = "2"
    descricao = "Prever minhas notas e a chance de aprovação"

    def executar(self, terminal):
        self.mostrar_disponiveis(terminal)
        carregada = terminal.pedir_materia()
        if carregada:
            materia, csv = carregada
            self.mostrar_previsao(terminal, materia, csv)
        return True

    def mostrar_disponiveis(self, terminal):
        disponiveis = terminal.sistema.materias_com_previsao()
        terminal.saida("\nMatérias com previsão disponível (turmas passadas):")
        for nome in disponiveis:
            terminal.saida(f"  - {nome}")
        if not disponiveis:
            terminal.saida("  (nenhuma: não há arquivos na pasta de histórico)")
        terminal.saida("O seu arquivo CSV de notas deve ter o MESMO NOME da matéria (ex.: calculo1.csv).")

    def mostrar_previsao(self, terminal, materia, csv):
        try:
            texto = terminal.sistema.relatorio_previsao(materia, csv)
        except (PrevisaoIndisponivelError, DadosInvalidosError) as erro:
            terminal.saida(f"Previsão indisponível: {erro}")
            return
        terminal.saida("\n" + texto)


class ComandoSair(Comando):
    tecla = "0"
    descricao = "Sair"

    def executar(self, terminal):
        terminal.saida("Até logo!")
        return False


# ==================== cli.py ====================

RAIZ = Path(__file__).resolve().parent
HISTORICO_PADRAO = RAIZ / "dados" / "historico"

LINHA = "=" * 62

#Para criar uma opcao nova: fazer a classe em comandos.py e colocar nesta lista
COMANDOS = [ComandoSituacao(), ComandoPrevisao(), ComandoSair()]


def montar_menu(comandos):
    linhas = ["", LINHA, " SISTEMA DE REPROVAÇÃO", LINHA]
    for comando in comandos:
        linhas.append(f" {comando.tecla} - {comando.descricao}")
    linhas.append(LINHA)
    return "\n".join(linhas)


def mensagem_opcao_invalida(comandos):
    teclas = [comando.tecla for comando in comandos]
    return f"Opção inválida. Digite {', '.join(teclas[:-1])} ou {teclas[-1]}."


def executar_terminal(pasta_historico, entrada=None, saida=None):
    """Laço do menu. Termina quando o aluno escolhe sair."""
    entrada = entrada or input  #resolvidos aqui
    saida = saida or print
    terminal = Terminal(SistemaReprovacao(pasta_historico), entrada, saida)
    opcoes = {comando.tecla: comando for comando in COMANDOS}

    continuar = True
    while continuar:
        saida(montar_menu(COMANDOS))
        comando = opcoes.get(entrada("Escolha uma opção: ").strip())
        if comando is None:
            saida(mensagem_opcao_invalida(COMANDOS))
        else:
            continuar = comando.executar(terminal)


#Ponto de entrada
def construir_parser():
    parser = argparse.ArgumentParser(
        prog="python sistema_reprovacao.py",
        description="Terminal para o aluno acompanhar sua situação em uma matéria e a chance de aprovação.",
    )
    parser.add_argument("--historico", default=str(HISTORICO_PADRAO),
                        help="pasta com um <matéria>.csv de turmas passadas por matéria "
                             "(padrão: dados/historico)")
    return parser


def main(argv=None):
    args = construir_parser().parse_args(argv)
    try:
        executar_terminal(args.historico)
    except (EOFError, KeyboardInterrupt):  # Ctrl+D / Ctrl+Z / Ctrl+C
        print("\nAté logo!")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
