"""Sistema de Reprovacao: testes automatizados em um unico arquivo.

Nos testes das historias, a docstring indica o criterio de aceitacao verificado
(H3-C2 = historia 3, criterio 2).
Para rodar, na mesma pasta do sistema_reprovacao.py:
    python -m pytest test_sistema_reprovacao.py
"""

import json
import os
import pytest
import subprocess
import sys
from pathlib import Path

from sistema_reprovacao import (
    COMANDOS,
    Comando,
    ComandoPrevisao,
    ComandoSair,
    ComandoSituacao,
    DadosInvalidosError,
    Leitor,
    LeitorCSV,
    LeitorJSON,
    Materia,
    PrevisaoIndisponivelError,
    RegressaoSimples,
    SistemaReprovacao,
    Terminal,
    buscar_historico,
    calcular_faltas_permitidas,
    calcular_nota_atual,
    calcular_nota_necessaria,
    calcular_nota_recuperacao,
    carregar_frequencia,
    carregar_materia,
    carregar_notas,
    carregar_regras,
    carregar_regras_da_materia,
    classificar_situacao,
    executar_terminal,
    formatar_numero,
    formatar_percentual,
    formatar_previsao,
    formatar_relatorio,
    gerar_previsao,
    gerar_relatorio,
    mensagem_opcao_invalida,
    montar_menu,
    normalizar_nome,
    prever,
    validar_consistencia,
)


# ==================== dados de exemplo (conftest.py) ====================

# Dados de exemplo que os testes das histórias usam (todos fictícios)


@pytest.fixture
def regras_calculo():
    "Regras de Calculo I: P1 e P2 valem 30% cada, o trabalho vale 40%."
    return {
        "media_aprovacao": 6.0,
        "avaliacoes": {"P1": 0.3, "P2": 0.3, "Trabalho": 0.4},
    }


@pytest.fixture
def regras_p1_p2():
    "Regras com só duas provas de 50% cada."
    return {
        "media_aprovacao": 6.0,
        "avaliacoes": {"P1": 0.5, "P2": 0.5},
    }


@pytest.fixture
def arquivos_validos(tmp_path):
    "Cria um CSV e um JSON válidos de Calculo I e devolve os dois caminhos."
    caminho_csv = tmp_path / "notas.csv"
    caminho_csv.write_text(
        "disciplina,avaliacao,nota\n"
        "Calculo I,P1,4\n"
        "Calculo I,P2,5\n"
        "Calculo I,Trabalho,\n",  # nota vazia = avaliação pendente
        encoding="utf-8",
    )

    regras = {
        "Calculo I": {
            "media_aprovacao": 6.0,
            "avaliacoes": {"P1": 0.3, "P2": 0.3, "Trabalho": 0.4},
        }
    }
    caminho_json = tmp_path / "regras.json"
    caminho_json.write_text(json.dumps(regras), encoding="utf-8")

    return caminho_csv, caminho_json


# ==================== test1.py ====================

# Teste história de usuário 1


def test_criterios_prof(arquivos_validos):
    "H1-C1: dado um JSON válido, o sistema lê os pesos do professor."
    _, js = arquivos_validos
    regras = carregar_regras(js)["Calculo I"]
    assert regras["avaliacoes"] == {"P1": 0.3, "P2": 0.3, "Trabalho": 0.4}

def test_calcular_notas(arquivos_validos):
    "H1-C2: dado um CSV válido, o sistema retorna a nota atual (P1=4, P2=5 -> 2,7)."
    csv, js = arquivos_validos
    notas = carregar_notas(csv)["Calculo I"]
    regras = carregar_regras(js)["Calculo I"]
    assert calcular_nota_atual(notas, regras) == pytest.approx(2.7)


def test_av_pendentes(regras_calculo):
    "H1-C3: avaliações pendentes não entram na soma."
    notas = {"P1": 4, "P2": 5, "Trabalho": None}
    assert calcular_nota_atual(notas, regras_calculo) == pytest.approx(2.7)


def test_nota_atual(regras_calculo):
    "H1-C4: nota atual = soma de (nota x peso) das avaliações realizadas."
    notas = {"P1": 4, "P2": 5, "Trabalho": 10}
    assert calcular_nota_atual(notas, regras_calculo) == pytest.approx(6.7)


# ==================== test2.py ====================

# teste história de usuário 2


def test_verifica_nota_atual():
    "H2-C1: nota atual >= 6 -> aprovado."
    regras = {"media_aprovacao": 6.0, "avaliacoes": {"P1": 0.6, "P2": 0.4}}
    assert classificar_situacao({"P1": 10, "P2": None}, regras) == "aprovado"
 
def test_verifica_reprovacao():
    "H2-C2: mesmo com 10 nas pendentes e recuperação, não chega a 6 -> reprovado."
    regras = {"media_aprovacao": 6.0, "avaliacoes": {"P1": 0.9, "P2": 0.1}}
    assert classificar_situacao({"P1": 0, "P2": None}, regras) == "reprovado"
  
def test_verifica_possibilidades(regras_calculo):
    "H2-C3: nota abaixo de 6, mas ainda alcançável nas pendentes -> em risco."
    notas = {"P1": 4, "P2": 5, "Trabalho": None}
    assert classificar_situacao(notas, regras_calculo) == "em risco"
 
def test_verifica_nota_presenca(regras_calculo):
    "H2-C4: nota final 7 exige 65% de presença; com 60% -> reprovado."
    notas = {"P1": 7, "P2": 7, "Trabalho": 7}
    assert classificar_situacao(notas, regras_calculo, presenca=0.60) == "reprovado"
 
def test_verifica_nota_presenca_atual(regras_calculo):
    "H2-C4: nota final 9 exige só 50% de presença; com 55% -> aprovado."
    notas = {"P1": 9, "P2": 9, "Trabalho": 9}
    assert classificar_situacao(notas, regras_calculo, presenca=0.55) == "aprovado"


# ==================== test3.py ====================

# Teste história de usuário 3


# Nos testes usamos 100 aulas para a conta dar número inteiro:
# 75% de presença -> 25 faltas no máximo
# 65% de presença -> 35 faltas no máximo
# 50% de presença -> 50 faltas no máximo

def test_informa_aulas_e_faltas():
    "H3-C1: o aluno informa aulas totais e faltas; sem aulas totais não há como calcular."
    assert calcular_faltas_permitidas(aulas_totais=100, faltas=10, nota_atual=6) == 15
    with pytest.raises(ValueError):
        calcular_faltas_permitidas(aulas_totais=0, faltas=0, nota_atual=6)

def test_limite_depende_da_nota():
    "H3-C2: com a mesma quantidade de faltas, a nota atual muda o limite (6 -> 15, 9 -> 40)."
    assert calcular_faltas_permitidas(100, 10, nota_atual=6) == 15
    assert calcular_faltas_permitidas(100, 10, nota_atual=9) == 40

def test_regras_fixas_de_presenca():
    "H3-C3: nota < 6.5 exige 75%, de 6.5 a menos de 8 exige 65%, de 8 em diante exige 50%."
    assert calcular_faltas_permitidas(100, 0, nota_atual=6.4) == 25
    assert calcular_faltas_permitidas(100, 0, nota_atual=6.5) == 35
    assert calcular_faltas_permitidas(100, 0, nota_atual=7.9) == 35
    assert calcular_faltas_permitidas(100, 0, nota_atual=8) == 50

def test_faltas_permitidas_com_nota_6():
    "H3-C4: aprovado com nota 6 -> presença mínima de 75%; 100 aulas e 10 faltas -> 15 faltas ainda permitidas."
    assert calcular_faltas_permitidas(100, 10, nota_atual=6) == 15


# ==================== test4.py ====================

# teste história de usuário 4


def test_nota_necessaria(regras_calculo):
    "H4-C1: (6 - 2,7) / 0,4 = 8,25."
    notas = {"P1": 4, "P2": 5, "Trabalho": None}
    assert calcular_nota_necessaria(notas, regras_calculo) == pytest.approx(8.25)

def test_ja_aprovado():
    "H4-C2: nota atual >= 6 -> nota necessária 0."
    regras = {"media_aprovacao": 6.0, "avaliacoes": {"P1": 0.6, "P2": 0.4}}
    assert calcular_nota_necessaria({"P1": 10, "P2": None}, regras) == 0

def test_recuperacao(regras_p1_p2):
    "H4-C3: nota necessária = 11 (> 10) e recuperação possível -> 'Recuperação'."
    notas = {"P1": 1, "P2": None}
    assert calcular_nota_necessaria(notas, regras_p1_p2) == "Recuperação"

def test_reprovado():
    "H4-C4: nota necessária 60 e recuperação > 10 -> 'Reprovado'."
    regras = {"media_aprovacao": 6.0, "avaliacoes": {"P1": 0.9, "P2": 0.1}}
    assert calcular_nota_necessaria({"P1": 0, "P2": None}, regras) == "Reprovado"

def test_nota_necessaria_recuperacao():
    "H4-C4: média final 4 -> (4 + rec) / 2 >= 6 -> rec = 8."
    assert calcular_nota_recuperacao(4.0) == pytest.approx(8.0)


# ==================== test_carregador.py ====================

# Testes do carregador (leitura e validacao dos arquivos)


CSV_CALCULO = (
    "disciplina,avaliacao,nota,aulas_totais,faltas\n"
    "Calculo 1,P1,4,60,8\n"
    "Calculo 1,P2,5,,\n"
    "Calculo 1,Trabalho,,,\n"
)
REGRAS_CALCULO = {
    "media_aprovacao": 6.0,
    "avaliacoes": {"P1": 0.3, "P2": 0.3, "Trabalho": 0.4},
}


def escrever(pasta, nome, texto):
    caminho = pasta / nome
    caminho.write_text(texto, encoding="utf-8")
    return caminho


def escrever_json(pasta, nome, conteudo):
    return escrever(pasta, nome, json.dumps(conteudo))


# carregar_notas

def test_carregar_notas_valido(arquivos_validos):
    csv, _ = arquivos_validos
    esperado = {"Calculo I": {"P1": 4.0, "P2": 5.0, "Trabalho": None}}
    assert carregar_notas(csv) == esperado


def test_nota_com_virgula(tmp_path):
    csv = escrever(tmp_path, "n.csv", 'disciplina,avaliacao,nota\nCalculo,P1,"7,5"\n')
    assert carregar_notas(csv)["Calculo"]["P1"] == 7.5


def test_arquivo_inexistente(tmp_path):
    with pytest.raises(DadosInvalidosError):
        carregar_notas(tmp_path / "nao_existe.csv")


def test_csv_sem_coluna_nota(tmp_path):
    csv = escrever(tmp_path, "n.csv", "disciplina,avaliacao\nCalculo,P1\n")
    with pytest.raises(DadosInvalidosError):
        carregar_notas(csv)


def test_csv_so_com_cabecalho(tmp_path):
    csv = escrever(tmp_path, "n.csv", "disciplina,avaliacao,nota\n")
    with pytest.raises(DadosInvalidosError):
        carregar_notas(csv)


@pytest.mark.parametrize("nota", ["11", "-1", "abc"])
def test_nota_invalida(tmp_path, nota):
    csv = escrever(tmp_path, "n.csv", f"disciplina,avaliacao,nota\nCalculo,P1,{nota}\n")
    with pytest.raises(DadosInvalidosError):
        carregar_notas(csv)


def test_avaliacao_repetida(tmp_path):
    texto = "disciplina,avaliacao,nota\nCalculo,P1,4\nCalculo,P1,5\n"
    csv = escrever(tmp_path, "n.csv", texto)
    with pytest.raises(DadosInvalidosError):
        carregar_notas(csv)


# carregar_regras

def test_carregar_regras_valido(arquivos_validos):
    _, js = arquivos_validos
    regras = carregar_regras(js)
    assert regras["Calculo I"]["avaliacoes"]["Trabalho"] == 0.4


def test_media_padrao_e_6(tmp_path):
    js = escrever_json(tmp_path, "r.json", {"Calculo": {"avaliacoes": {"P1": 1}}})
    assert carregar_regras(js)["Calculo"]["media_aprovacao"] == 6.0


def test_json_quebrado(tmp_path):
    js = escrever(tmp_path, "r.json", "{ isso nao e json")
    with pytest.raises(DadosInvalidosError):
        carregar_regras(js)


def test_pesos_nao_somam_1(tmp_path):
    regras = {"Calculo": {"avaliacoes": {"P1": 0.5, "P2": 0.3}}}
    js = escrever_json(tmp_path, "r.json", regras)
    with pytest.raises(DadosInvalidosError):
        carregar_regras(js)


def test_peso_zero(tmp_path):
    regras = {"Calculo": {"avaliacoes": {"P1": 0, "P2": 1}}}
    js = escrever_json(tmp_path, "r.json", regras)
    with pytest.raises(DadosInvalidosError):
        carregar_regras(js)


def test_regra_sem_avaliacoes(tmp_path):
    js = escrever_json(tmp_path, "r.json", {"Calculo": {"media_aprovacao": 6}})
    with pytest.raises(DadosInvalidosError):
        carregar_regras(js)


# carregar_regras_da_materia

def test_regras_de_uma_materia(tmp_path):
    js = escrever_json(tmp_path, "r.json", REGRAS_CALCULO)
    assert carregar_regras_da_materia(js, "qualquer")["avaliacoes"]["P1"] == 0.3


def test_regras_achadas_pelo_nome_sem_acento(tmp_path):
    js = escrever_json(tmp_path, "r.json", {"Cálculo I": REGRAS_CALCULO})
    regras = carregar_regras_da_materia(js, "calculo i")
    assert regras["avaliacoes"]["Trabalho"] == 0.4


def test_materia_sem_regras(tmp_path):
    js = escrever_json(tmp_path, "r.json", {"Calculo": REGRAS_CALCULO})
    with pytest.raises(DadosInvalidosError):
        carregar_regras_da_materia(js, "Fisica")


# carregar_frequencia

def test_carregar_frequencia(tmp_path):
    csv = escrever(tmp_path, "n.csv", CSV_CALCULO)
    assert carregar_frequencia(csv) == {"Calculo 1": {"aulas_totais": 60, "faltas": 8}}


def test_frequencia_sem_as_colunas(arquivos_validos):
    csv, _ = arquivos_validos
    assert carregar_frequencia(csv) == {}


def test_faltas_maior_que_aulas(tmp_path):
    texto = "disciplina,avaliacao,nota,aulas_totais,faltas\nCalculo,P1,4,10,20\n"
    csv = escrever(tmp_path, "n.csv", texto)
    with pytest.raises(DadosInvalidosError):
        carregar_frequencia(csv)


def test_so_faltas_sem_aulas(tmp_path):
    texto = "disciplina,avaliacao,nota,aulas_totais,faltas\nCalculo,P1,4,,3\n"
    csv = escrever(tmp_path, "n.csv", texto)
    with pytest.raises(DadosInvalidosError):
        carregar_frequencia(csv)


# validar_consistencia

def test_consistencia_ok():
    notas = {"Calculo": {"P1": 4.0, "P2": None}}
    regras = {"Calculo": {"media_aprovacao": 6.0, "avaliacoes": {"P1": 0.5, "P2": 0.5}}}
    validar_consistencia(notas, regras)


def test_disciplina_sem_regras():
    with pytest.raises(DadosInvalidosError):
        validar_consistencia({"Fisica": {"P1": 4.0}}, {})


def test_avaliacao_fora_das_regras():
    notas = {"Calculo": {"P1": 4.0, "P3": 5.0}}
    regras = {"Calculo": {"media_aprovacao": 6.0, "avaliacoes": {"P1": 1.0}}}
    with pytest.raises(DadosInvalidosError):
        validar_consistencia(notas, regras)


# carregar_materia

def test_carregar_materia(tmp_path):
    csv = escrever(tmp_path, "calculo1.csv", CSV_CALCULO)
    js = escrever_json(tmp_path, "calculo1.json", REGRAS_CALCULO)
    materia = carregar_materia(csv, js)
    assert materia.nome == "Calculo 1"
    assert materia.notas["P2"] == 5.0
    assert materia.frequencia == {"aulas_totais": 60, "faltas": 8}


def test_csv_com_duas_materias(tmp_path):
    texto = "disciplina,avaliacao,nota\nCalculo,P1,4\nFisica,P1,5\n"
    csv = escrever(tmp_path, "n.csv", texto)
    js = escrever_json(tmp_path, "r.json", REGRAS_CALCULO)
    with pytest.raises(DadosInvalidosError):
        carregar_materia(csv, js)


# historico

def test_normalizar_nome():
    assert normalizar_nome("Cálculo 1") == "calculo1"
    assert normalizar_nome("fisica_1") == "fisica1"


def test_buscar_historico(tmp_path):
    escrever(tmp_path, "calculo1.csv", "aluno,P1,P2\nA1,5.5,6\nA2,7,8\n")
    historico = buscar_historico(tmp_path, "Cálculo 1")
    assert historico == [{"P1": 5.5, "P2": 6.0}, {"P1": 7.0, "P2": 8.0}]


def test_historico_de_materia_inexistente(tmp_path):
    assert buscar_historico(tmp_path, "Fisica") is None


def test_pasta_de_historico_inexistente(tmp_path):
    assert buscar_historico(tmp_path / "nao_existe", "Fisica") is None


# ==================== test_predicao.py ====================

# Testes da predicao (regressao linear simples)


def historico_igual(quantidade=10):
    "Alunos de turmas passadas em que a P2 foi igual a P1."
    return [{"P1": nota, "P2": nota} for nota in range(1, quantidade + 1)]


# RegressaoSimples

def test_reta_exata():
    modelo = RegressaoSimples.treinar([1, 2, 3, 4], [3, 5, 7, 9])
    assert modelo.coeficiente == pytest.approx(2)
    assert modelo.intercepto == pytest.approx(1)
    assert modelo.erro_padrao == pytest.approx(0, abs=1e-9)
    assert modelo.r2 == pytest.approx(1)


def test_prever_com_a_reta():
    modelo = RegressaoSimples.treinar([1, 2, 3, 4], [3, 5, 7, 9])
    assert modelo.prever(10) == pytest.approx(21)


def test_poucas_observacoes():
    with pytest.raises(PrevisaoIndisponivelError):
        RegressaoSimples.treinar([1, 2], [3, 5])


def test_todos_com_a_mesma_nota_base():
    with pytest.raises(PrevisaoIndisponivelError):
        RegressaoSimples.treinar([5, 5, 5], [3, 5, 7])


# prever

def test_previsao_de_quem_vai_mal(regras_p1_p2):
    resultado = prever(historico_igual(), {"P1": 4, "P2": None}, regras_p1_p2)
    assert resultado.notas_previstas["P2"] == pytest.approx(4)
    assert resultado.media_final_prevista == pytest.approx(4)
    assert resultado.chance_aprovacao == 0


def test_previsao_de_quem_vai_bem(regras_p1_p2):
    resultado = prever(historico_igual(), {"P1": 8, "P2": None}, regras_p1_p2)
    assert resultado.media_final_prevista == pytest.approx(8)
    assert resultado.chance_aprovacao == 1


def test_chance_entre_0_e_1_e_cresce_com_a_nota(regras_p1_p2):
    # Com ruido na P2 a previsao deixa de ser certa
    historico = [
        {"P1": nota, "P2": nota + (1 if nota % 2 == 0 else -1)}
        for nota in range(1, 11)
    ]
    chance_baixa = prever(historico, {"P1": 5, "P2": None}, regras_p1_p2).chance_aprovacao
    chance_alta = prever(historico, {"P1": 7, "P2": None}, regras_p1_p2).chance_aprovacao
    assert 0 < chance_baixa < chance_alta < 1


def test_chance_abaixo_da_media(regras_p1_p2):
    resultado = prever(historico_igual(), {"P1": 8, "P2": None}, regras_p1_p2)
    assert resultado.chance_abaixo_da_media == 0


def test_nota_prevista_nao_passa_de_10(regras_p1_p2):
    historico = [{"P1": nota, "P2": 2 * nota} for nota in range(10)]
    resultado = prever(historico, {"P1": 10, "P2": None}, regras_p1_p2)
    assert resultado.notas_previstas["P2"] == 10


def test_sem_avaliacoes_pendentes(regras_p1_p2):
    resultado = prever([], {"P1": 8, "P2": 8}, regras_p1_p2)
    assert resultado.notas_previstas == {}
    assert resultado.chance_aprovacao == 1


def test_sem_nenhuma_nota_conhecida(regras_p1_p2):
    with pytest.raises(PrevisaoIndisponivelError):
        prever(historico_igual(), {"P1": None, "P2": None}, regras_p1_p2)


def test_historico_pequeno_demais(regras_p1_p2):
    with pytest.raises(PrevisaoIndisponivelError):
        prever(historico_igual(5), {"P1": 4, "P2": None}, regras_p1_p2)


# ==================== test_relatorio.py ====================

# Testes do relatorio (montagem e formatacao do texto)


FREQUENCIA = {"aulas_totais": 60, "faltas": 8}


def materia_calculo(regras, frequencia=None, notas=None):
    notas = notas or {"P1": 4.0, "P2": 5.0, "Trabalho": None}
    return Materia("Calculo 1", notas, regras, frequencia)


def escrever_historico(pasta, alunos=12):
    linhas = ["aluno,P1,P2,Trabalho"]
    for numero in range(alunos):
        nota = 2 + numero * 0.5
        linhas.append(f"A{numero},{nota},{nota},{nota}")
    (pasta / "calculo1.csv").write_text("\n".join(linhas), encoding="utf-8")


# gerar_relatorio

def test_relatorio_sem_frequencia(regras_calculo):
    relatorio = gerar_relatorio(materia_calculo(regras_calculo))
    assert relatorio.nota_atual == pytest.approx(2.7)
    assert relatorio.situacao == "em risco"
    assert relatorio.nota_necessaria == pytest.approx(8.25)
    assert relatorio.avaliacoes_pendentes == ["Trabalho"]
    assert relatorio.faltas_permitidas is None


def test_relatorio_com_frequencia(regras_calculo):
    relatorio = gerar_relatorio(materia_calculo(regras_calculo, FREQUENCIA))
    assert relatorio.presenca == pytest.approx(52 / 60)
    assert relatorio.presenca_minima == 0.75
    assert relatorio.faltas_permitidas == 7


def test_relatorio_de_quem_ja_passou(regras_calculo):
    notas = {"P1": 8.0, "P2": 8.0, "Trabalho": 8.0}
    relatorio = gerar_relatorio(materia_calculo(regras_calculo, notas=notas))
    assert relatorio.situacao == "aprovado"
    assert relatorio.nota_necessaria == 0
    assert relatorio.avaliacoes_pendentes == []


# formatacao

def test_formatar_numero():
    assert formatar_numero(2.7) == "2,70"
    assert formatar_numero(8.254, casas=1) == "8,3"


def test_formatar_percentual():
    assert formatar_percentual(0.5) == "50,0%"
    assert formatar_percentual(0) == "0,0%"
    assert formatar_percentual(1) == "100,0%"
    assert formatar_percentual(0.0004) == "< 0,1%"
    assert formatar_percentual(0.9995) == "> 99,9%"


def test_texto_do_relatorio(regras_calculo):
    relatorio = gerar_relatorio(materia_calculo(regras_calculo, FREQUENCIA))
    texto = formatar_relatorio(relatorio)
    assert "Calculo 1" in texto
    assert "2,70" in texto
    assert "EM RISCO" in texto
    assert "8,25" in texto
    assert "Faltas ainda permitidas" in texto


def test_texto_do_relatorio_sem_frequencia(regras_calculo):
    relatorio = gerar_relatorio(materia_calculo(regras_calculo))
    assert "Faltas ainda permitidas" not in formatar_relatorio(relatorio)


def test_texto_quando_so_a_recuperacao_salva(regras_p1_p2):
    materia = Materia("Algoritmos", {"P1": 1.0, "P2": None}, regras_p1_p2, None)
    texto = formatar_relatorio(gerar_relatorio(materia))
    assert "Recuperação" in texto


# previsao

def test_previsao_sem_historico(tmp_path, regras_calculo):
    with pytest.raises(PrevisaoIndisponivelError):
        gerar_previsao(materia_calculo(regras_calculo), "calculo1", tmp_path)


def test_previsao_com_historico(tmp_path, regras_calculo):
    escrever_historico(tmp_path)
    materia = materia_calculo(regras_calculo)
    predicao = gerar_previsao(materia, "calculo1", tmp_path)
    assert "Trabalho" in predicao.notas_previstas
    assert 0 <= predicao.chance_aprovacao <= 1


def test_texto_da_previsao(tmp_path, regras_calculo):
    escrever_historico(tmp_path)
    materia = materia_calculo(regras_calculo)
    predicao = gerar_previsao(materia, "calculo1", tmp_path)
    texto = formatar_previsao(materia, predicao)
    assert "Previsão" in texto
    assert "Chance de aprovação direta" in texto


def test_texto_da_previsao_sem_pendentes(tmp_path, regras_calculo):
    escrever_historico(tmp_path)
    notas = {"P1": 8.0, "P2": 8.0, "Trabalho": 8.0}
    materia = materia_calculo(regras_calculo, notas=notas)
    predicao = gerar_previsao(materia, "calculo1", tmp_path)
    assert "Nada a prever" in formatar_previsao(materia, predicao)


# ==================== test_cli.py ====================

# Testes do terminal (menu e opcoes)


RAIZ = Path(__file__).resolve().parent


def rodar_menu(respostas, pasta_historico):
    "Roda o menu com as respostas combinadas e devolve tudo que foi escrito."
    respostas = iter(respostas)
    textos = []
    executar_terminal(pasta_historico, lambda pergunta: next(respostas), textos.append)
    return "\n".join(textos)


def test_sair(tmp_path):
    assert "Até logo!" in rodar_menu(["0"], tmp_path)


def test_opcao_invalida(tmp_path):
    saida = rodar_menu(["9", "0"], tmp_path)
    assert "Opção inválida" in saida


def test_ver_situacao(tmp_path, arquivos_validos):
    csv, js = arquivos_validos
    saida = rodar_menu(["1", str(csv), str(js), "0"], tmp_path)
    assert "2,70" in saida
    assert "EM RISCO" in saida


def test_situacao_com_arquivo_inexistente(tmp_path):
    saida = rodar_menu(["1", "nao_existe.csv", "nao_existe.json", "0"], tmp_path)
    assert "Erro:" in saida


def test_voltar_ao_menu(tmp_path):
    saida = rodar_menu(["1", "0", "0"], tmp_path)
    assert "Até logo!" in saida
    assert "Erro:" not in saida


def test_previsao_sem_historico_cli(tmp_path, arquivos_validos):
    csv, js = arquivos_validos
    saida = rodar_menu(["2", str(csv), str(js), "0"], tmp_path)
    assert "Previsão indisponível" in saida


def test_rodar_pelo_terminal():
    ambiente = dict(os.environ, PYTHONIOENCODING="utf-8")
    resultado = subprocess.run(
        [sys.executable, "sistema_reprovacao.py"],
        input="0\n",
        capture_output=True,
        text=True,
        encoding="utf-8",
        cwd=RAIZ,
        env=ambiente,
    )
    assert resultado.returncode == 0
    assert "SISTEMA DE REPROVAÇÃO" in resultado.stdout


# ==================== test_leitores.py ====================

# Testes dos leitores (padrao Template Method)


class LeitorQueAnota(Leitor):
    "Leitor de mentira que guarda a ordem em que os passos foram chamados."

    def __init__(self):
        self.passos = []

    def verificar_existe(self, caminho):
        self.passos.append("verificar")

    def ler_conteudo(self, caminho):
        self.passos.append("ler")
        return "conteudo"

    def validar(self, caminho, conteudo):
        self.passos.append("validar")


def escrever_leitores(pasta, nome, texto):
    caminho = pasta / nome
    caminho.write_text(texto, encoding="utf-8")
    return caminho


def test_ordem_dos_passos():
    leitor = LeitorQueAnota()
    assert leitor.ler("qualquer.txt") == "conteudo"
    assert leitor.passos == ["verificar", "ler", "validar"]


def test_leitor_base_nao_le_nada(tmp_path):
    arquivo = escrever_leitores(tmp_path, "a.txt", "x")
    with pytest.raises(NotImplementedError):
        Leitor().ler(arquivo)


@pytest.mark.parametrize("leitor", [LeitorCSV(), LeitorJSON()])
def test_arquivo_inexistente_leitores(tmp_path, leitor):
    with pytest.raises(DadosInvalidosError):
        leitor.ler(tmp_path / "nao_existe")


def test_ler_csv(tmp_path):
    arquivo = escrever_leitores(tmp_path, "a.csv", "nome , nota\nAna, 7\n")
    colunas, linhas = LeitorCSV(["nome"]).ler(arquivo)
    assert colunas == ["nome", "nota"]
    assert linhas == [(2, {"nome": "Ana", "nota": "7"})]


def test_csv_sem_coluna_obrigatoria(tmp_path):
    arquivo = escrever_leitores(tmp_path, "a.csv", "nome\nAna\n")
    with pytest.raises(DadosInvalidosError):
        LeitorCSV(["nota"]).ler(arquivo)


def test_ler_json(tmp_path):
    arquivo = escrever_leitores(tmp_path, "a.json", '{"P1": 1}')
    assert LeitorJSON().ler(arquivo) == {"P1": 1}


@pytest.mark.parametrize("texto", ["{ quebrado", "[1, 2]", "{}"])
def test_json_invalido(tmp_path, texto):
    arquivo = escrever_leitores(tmp_path, "a.json", texto)
    with pytest.raises(DadosInvalidosError):
        LeitorJSON().ler(arquivo)


# ==================== test_fachada.py ====================

# Testes da fachada (padrao Facade)


def escrever_historico_fachada(pasta, nome):
    linhas = ["aluno,P1,P2,Trabalho"]
    for numero in range(12):
        nota = 2 + numero * 0.5
        linhas.append(f"A{numero},{nota},{nota},{nota}")
    (pasta / f"{nome}.csv").write_text("\n".join(linhas), encoding="utf-8")


def test_materias_em_ordem(tmp_path):
    escrever_historico_fachada(tmp_path, "fisica1")
    escrever_historico_fachada(tmp_path, "calculo1")
    sistema = SistemaReprovacao(tmp_path)
    assert sistema.materias_com_previsao() == ["calculo1", "fisica1"]


def test_sem_pasta_de_historico(tmp_path):
    sistema = SistemaReprovacao(tmp_path / "nao_existe")
    assert sistema.materias_com_previsao() == []


def test_relatorio_de_situacao(tmp_path, arquivos_validos):
    csv, js = arquivos_validos
    sistema = SistemaReprovacao(tmp_path)
    materia = sistema.carregar_materia(csv, js)
    texto = sistema.relatorio_situacao(materia)
    assert "2,70" in texto
    assert "EM RISCO" in texto


def test_relatorio_de_previsao(tmp_path, arquivos_validos):
    csv, js = arquivos_validos
    # o arquivo de notas da fixture se chama notas.csv, entao o historico
    # precisa do mesmo nome, em outra pasta para nao sobrescrever
    pasta = tmp_path / "historico"
    pasta.mkdir()
    escrever_historico_fachada(pasta, "notas")
    sistema = SistemaReprovacao(pasta)
    materia = sistema.carregar_materia(csv, js)
    assert "Chance de aprovação" in sistema.relatorio_previsao(materia, csv)


def test_previsao_sem_historico_fachada(tmp_path, arquivos_validos):
    csv, js = arquivos_validos
    sistema = SistemaReprovacao(tmp_path / "vazia")
    materia = sistema.carregar_materia(csv, js)
    with pytest.raises(PrevisaoIndisponivelError):
        sistema.relatorio_previsao(materia, csv)


# ==================== test_comandos.py ====================

# Testes dos comandos do menu (padrao Command)


def criar_terminal(pasta, respostas=()):
    "Terminal de teste: responde com a lista e guarda o que foi escrito."
    respostas = iter(respostas)
    textos = []
    sistema = SistemaReprovacao(pasta)
    terminal = Terminal(sistema, lambda pergunta: next(respostas), textos.append)
    return terminal, textos


def test_comando_base_nao_faz_nada(tmp_path):
    terminal, _ = criar_terminal(tmp_path)
    with pytest.raises(NotImplementedError):
        Comando().executar(terminal)


def test_sair_fecha_o_menu(tmp_path):
    terminal, textos = criar_terminal(tmp_path)
    assert ComandoSair().executar(terminal) is False
    assert textos == ["Até logo!"]


def test_situacao_mantem_o_menu(tmp_path, arquivos_validos):
    csv, js = arquivos_validos
    terminal, textos = criar_terminal(tmp_path, [str(csv), str(js)])
    assert ComandoSituacao().executar(terminal) is True
    assert "EM RISCO" in textos[-1]


def test_enter_reaproveita_os_arquivos(tmp_path, arquivos_validos):
    csv, js = arquivos_validos
    terminal, textos = criar_terminal(tmp_path, [str(csv), str(js), "", ""])
    ComandoSituacao().executar(terminal)
    textos.clear()
    ComandoSituacao().executar(terminal)
    assert "EM RISCO" in textos[-1]


def test_previsao_sem_historico_comandos(tmp_path, arquivos_validos):
    csv, js = arquivos_validos
    terminal, textos = criar_terminal(tmp_path / "vazia", [str(csv), str(js)])
    assert ComandoPrevisao().executar(terminal) is True
    assert "Previsão indisponível" in textos[-1]


def test_teclas_nao_se_repetem():
    teclas = [comando.tecla for comando in COMANDOS]
    assert len(teclas) == len(set(teclas))


def test_menu_lista_todos_os_comandos():
    menu = montar_menu(COMANDOS)
    for comando in COMANDOS:
        assert f"{comando.tecla} - {comando.descricao}" in menu


def test_mensagem_de_opcao_invalida():
    assert mensagem_opcao_invalida(COMANDOS) == "Opção inválida. Digite 1, 2 ou 0."
